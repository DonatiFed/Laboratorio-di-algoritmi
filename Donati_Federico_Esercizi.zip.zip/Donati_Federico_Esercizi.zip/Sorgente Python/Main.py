##modificare parametro della funzione per eseguire il test:

##1)esegue test brute-force
##2)esegue test algoritmo ricorsivo
##3)esegue test algoritmo ricorsivo con memoization
##4)esegue test algoritmo iterativo
from Lcs_Tests import*
eseguiTest(1)

